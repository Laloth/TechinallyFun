package JAKJ . RedstoneInMotion ;

public class PacketHandler implements cpw . mods . fml . common . network . IPacketHandler
{
	public static void DispatchPacket ( CarriagePackage Package )
	{
		try
		{
			java . io . ByteArrayOutputStream DataStore = new java . io . ByteArrayOutputStream ( ) ;
			java . io . DataOutputStream Data  = new java . io . DataOutputStream ( DataStore ) ;

			int AnchorX = Package . AnchorRecord . X + Package . MotionDirection . DeltaX ;
			int AnchorY = Package . AnchorRecord . Y + Package . MotionDirection . DeltaY ;
			int AnchorZ = Package . AnchorRecord . Z + Package . MotionDirection . DeltaZ ;

			Data . writeInt ( AnchorX ) ;
			Data . writeInt ( AnchorY ) ;
			Data . writeInt ( AnchorZ ) ;

			Data . writeInt ( Package . DriveRecord . X ) ;
			Data . writeInt ( Package . DriveRecord . Y ) ;
			Data . writeInt ( Package . DriveRecord . Z ) ;

			Data . writeBoolean ( Package . DriveIsAnchored ) ;

			Data . writeInt ( Package . Blocks . size ( ) ) ;

			for ( BlockRecord Record : Package . Blocks )
			{
				Data . writeInt ( Record . X ) ;
				Data . writeInt ( Record . Y ) ;
				Data . writeInt ( Record . Z ) ;
			}

			cpw . mods . fml . common . network . PacketDispatcher . sendPacketToAllAround
			(
				AnchorX + 0.5 , AnchorY + 0.5 , AnchorZ + 0.5 ,
				64 ,
				Package . World . provider . dimensionId ,
				cpw . mods . fml . common . network . PacketDispatcher . getPacket ( "JAKJ_RIM" , DataStore . toByteArray ( ) )
			) ;
		}
		catch ( Throwable Throwable )
		{
			Throwable . printStackTrace ( ) ;
		}
	}

	@Override
	public void onPacketData ( net . minecraft . network . INetworkManager NetworkManager , net . minecraft . network . packet . Packet250CustomPayload Packet , cpw . mods . fml . common . network . Player PlayerObject )
	{
		try
		{
			java . io . DataInputStream Data = new java . io . DataInputStream ( new java . io . ByteArrayInputStream ( Packet . data ) ) ;

			int AnchorX = Data . readInt ( ) ;
			int AnchorY = Data . readInt ( ) ;
			int AnchorZ = Data . readInt ( ) ;

			int DriveX = Data . readInt ( ) ;
			int DriveY = Data . readInt ( ) ;
			int DriveZ = Data . readInt ( ) ;

			boolean DriveIsAnchored = Data . readBoolean ( ) ;

			int BlockCount = Data . readInt ( ) ;

			BlockRecordList Blocks = new BlockRecordList ( ) ;

			BlockRecordList TileEntities = new BlockRecordList ( ) ;

			net . minecraft . entity . player . EntityPlayer Player = ( net . minecraft . entity . player . EntityPlayer ) PlayerObject ;

			for ( int Index = 0 ; Index < BlockCount ; Index ++ )
			{
				BlockRecord Record = new BlockRecord ( Data . readInt ( ) , Data . readInt ( ) , Data . readInt ( ) ) ;

				Record . Identify ( Player . worldObj ) ;

				Blocks . add ( Record ) ;

				if ( Record . Entity != null )
				{
					TileEntities . add ( Record ) ;
				}

				if ( ! DriveIsAnchored )
				{
					if ( Record . X == DriveX )
					{
						if ( Record . Y == DriveY )
						{
							if ( Record . Z == DriveZ )
							{
								( ( CarriageDriveEntity ) Record . Entity ) . Active = true ;
							}
						}
					}
				}
			}

			CarriageRenderCache . Assemble ( AnchorX , AnchorY , AnchorZ , Blocks , TileEntities , Player . worldObj ) ;
		}
		catch ( Throwable Throwable )
		{
			Throwable . printStackTrace ( ) ;
		}
	}
}
