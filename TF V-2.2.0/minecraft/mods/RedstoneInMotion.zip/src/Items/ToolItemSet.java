package JAKJ . RedstoneInMotion ;

import net . minecraft . world . World ;

public class ToolItemSet extends Item
{
	public static int Id ;

	public enum Types
	{
		Screwdriver ( "Screwdriver" ) ;

		public final String Name ;

		public final IconHolder Icon ;

		private Types ( String Name )
		{
			this . Name = Name ;

			Icon = new IconHolder ( name ( ) ) ;
		}
	}

	public ToolItemSet ( )
	{
		super ( Id ) ;

		setMaxStackSize ( 1 ) ;
	}

	@Override
	public String GetName ( Stack Stack )
	{
		return ( Types . values ( ) [ Stack . GetDamage ( ) ] . Name ) ;
	}

	@Override
	public void RegisterShowcaseStacks ( )
	{
		for ( Types Type : Types . values ( ) )
		{
			RegisterShowcaseStack ( new Stack ( this , Type ) ) ;
		}
	}

	@Override
	public void RegisterIcons ( IconRegister Register )
	{
		for ( Types Type : Types . values ( ) )
		{
			Register . Register ( Type . Icon ) ;
		}
	}

	@Override
	public IconHolder GetIcon ( int Damage )
	{
		return ( Types . values ( ) [ Damage ] . Icon ) ;
	}

	public static boolean IsScrewdriverOrEquivalent ( net . minecraft . item . ItemStack Item )
	{
		if ( Item == null )
		{
			return ( false ) ;
		}

		if ( Item . itemID == Items . ToolItemSet . itemID )
		{
			if ( Item . getItemDamage ( ) == Types . Screwdriver . ordinal ( ) )
			{
				return ( true ) ;
			}
		}

		if ( ModInteraction . OmniwrenchClass != null )
		{
			if ( ModInteraction . OmniwrenchClass . isInstance ( Item . getItem ( ) ) )
			{
				return ( true ) ;
			}
		}

		return ( false ) ;
	}
}
