package JAKJ . RedstoneInMotion ;

public class SimpleItemSet extends Item
{
	public static int Id ;

	public SimpleItemSet ( )
	{
		super ( Id ) ;
	}

	public enum Types
	{
		CarriageCrosspiece ( "Carriage Crosspiece" ) ,
		CarriagePanel ( "Carriage Panel" ) ,
		CarriageFramework ( "Carriage Framework" ) ;

		public final String Name ;

		public final IconHolder Icon ;

		private Types ( String Name )
		{
			this . Name = Name ;

			Icon = new IconHolder ( name ( ) ) ;
		}
	}

	@Override
	public String GetName ( Stack Stack )
	{
		return ( Types . values ( ) [ Stack . GetDamage ( ) ] . Name ) ;
	}

	@Override
	public void RegisterShowcaseStacks ( )
	{
		for ( Types Type : Types . values ( ) )
		{
			RegisterShowcaseStack ( new Stack ( this , Type ) ) ;
		}
	}

	@Override
	public void RegisterIcons ( IconRegister Register )
	{
		for ( Types Type : Types . values ( ) )
		{
			Register . Register ( Type . Icon ) ;
		}
	}

	@Override
	public IconHolder GetIcon ( int Index )
	{
		return ( Types . values ( ) [ Index ] . Icon ) ;
	}
}
