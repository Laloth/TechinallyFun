package JAKJ . RedstoneInMotion ;

public class CreativeTab extends net . minecraft . creativetab . CreativeTabs
{
	public CreativeTab ( )
	{
		super ( Core . Handle ) ;
	}

	public static CreativeTab Instance ;

	public static void Initialize ( )
	{
		Instance = new CreativeTab ( ) ;
	}

	@Override
	public String getTranslatedTabLabel ( )
	{
		return ( Core . Name ) ;
	}

	@Override
	public int getTabIconItemIndex ( )
	{
		return ( Blocks . Carriage . blockID ) ;
	}
}
