package JAKJ . RedstoneInMotion ;

public class Spectre extends net . minecraft . block . Block
{
	public Spectre ( )
	{
		super ( Configuration . BlockIds . Spectre , new net . minecraft . block . material . Material ( bedrock . blockMaterial . materialMapColor ) ) ;

		setUnlocalizedName ( Core . Handle + "_" + getClass ( ) . getSimpleName ( ) ) ;

		setHardness ( bedrock . blockHardness ) ;

		setStepSound ( bedrock . stepSound ) ;

		Registry . RegisterBlock ( this , net . minecraft . item . ItemBlock . class ) ;

		Registry . RegisterTileEntity ( MotiveSpectreEntity . class ) ;
	}

	public enum Types
	{
		Motive ,
		Supportive ;
	}

	@Override
	public boolean hasTileEntity ( int Meta )
	{
		return ( Meta == Types . Motive . ordinal ( ) ) ;
	}

	@Override
	public net . minecraft . tileentity . TileEntity createTileEntity ( net . minecraft . world . World World , int Meta )
	{
		if ( Meta == Types . Motive . ordinal ( ) )
		{
			return ( new MotiveSpectreEntity ( ) ) ;
		}

		return ( null ) ;
	}

	public static net . minecraft . util . Icon PlaceholderIcon ;

	@Override
	public void registerIcons ( net . minecraft . client . renderer . texture . IconRegister IconRegister )
	{
		PlaceholderIcon = Registry . RegisterIcon ( IconRegister , "CarriagePlaceholder" ) ;
	}

	@Override
	public net . minecraft . util . Icon getIcon ( int Side , int Meta )
	{
		return ( PlaceholderIcon ) ;
	}

	@Override
	public boolean onBlockActivated ( net . minecraft . world . World World , int X , int Y , int Z , net . minecraft . entity . player . EntityPlayer Player , int Side , float HitX , float HitY , float HitZ )
	{
		if ( World . isRemote )
		{
			return ( false ) ;
		}

		if ( World . getBlockMetadata ( X , Y , Z ) == Types . Motive . ordinal ( ) )
		{
			return ( false ) ;
		}

		if ( ! ToolItemSet . IsScrewdriverOrEquivalent ( Player . inventory . getCurrentItem ( ) ) )
		{
			return ( false ) ;
		}

		WorldUtil . ClearBlock ( World , X , Y , Z ) ;

		return ( true ) ;
	}

	@Override
	public int quantityDropped ( int Meta , int Fortune , java . util . Random Random )
	{
		return ( 0 ) ;
	}

	@Override
	public int getRenderType ( )
	{
		return ( -1 ) ;
	}

	@Override
	public boolean isOpaqueCube ( )
	{
		return ( false ) ;
	}

	@Override
	public boolean renderAsNormalBlock ( )
	{
		return ( false ) ;
	}
}
