package JAKJ . RedstoneInMotion ;

public class MotiveSpectreRendererWorld extends net . minecraft . world . World
{
	public BlockRecordSet Ghosts ;

	public MotiveSpectreRendererWorld ( net . minecraft . world . World World , BlockRecordSet Ghosts )
	{
		super ( null , "" , null , new net . minecraft . world . WorldSettings ( 0 , null , false , false , null ) , null , null ) ;

		try
		{
			for ( java . lang . reflect . Field Field : net . minecraft . world . World . class . getDeclaredFields ( ) )
			{
				Field . setAccessible ( true ) ;

				java . lang . reflect . Field Modifiers = java . lang . reflect . Field . class . getDeclaredField ( "modifiers" ) ;

				Modifiers . setAccessible ( true ) ;

				Modifiers . setInt ( Field , Field . getModifiers ( ) & ( ~ java . lang . reflect . Modifier . FINAL ) ) ;

				Field . set ( this , Field . get ( World ) ) ;
			}
		}
		catch ( Throwable Throwable )
		{
			throw ( new RuntimeException ( Throwable ) ) ;
		}

		this . Ghosts = Ghosts ;

		for ( BlockRecord Record : Ghosts )
		{
			if ( Record . EntityPacketRecord != null )
			{
				if ( Record . Entity == null )
				{
					Record . Entity = Block . Get ( Record . Id ) . createTileEntity ( this , Record . Meta ) ;

					Record . Entity . xCoord = Record . X ;
					Record . Entity . yCoord = Record . Y ;
					Record . Entity . zCoord = Record . Z ;

					Record . Entity . worldObj = this ;
				}

				try
				{
					net . minecraft . network . packet . Packet132TileEntityData Packet = new net . minecraft . network . packet . Packet132TileEntityData
					(
						Record . X , Record . Y , Record . Z , Record . EntityPacketRecord . getInteger ( "actionType" ) , Record . EntityPacketRecord . getCompoundTag ( "customParam1" )
					) ;

					Record . Entity . onDataPacket ( null , Packet ) ;
				}
				catch ( Throwable Throwable )
				{
					Throwable . printStackTrace ( ) ;

					Record . Entity . invalidate ( ) ;

					Record . Entity = null ;
				}
			}
			else if ( Record . EntityRecord != null )
			{
				try
				{
					Record . Entity = net . minecraft . tileentity . TileEntity . createAndLoadEntity ( Record . EntityRecord ) ;

					Record . Entity . worldObj = this ;
				}
				catch ( Throwable Throwable )
				{
					Throwable . printStackTrace ( ) ;
				}
			}

			if ( Record . Entity != null )
			{
				try
				{
					if ( Class . forName ( "buildcraft.transport.TileGenericPipe" ) . isInstance ( Record . Entity ) )
					{
						try
						{
							Class . forName ( "buildcraft.transport.Pipe" ) . getDeclaredField ( "worldObj" ) . set
							(
								Class . forName ( "buildcraft.transport.TileGenericPipe" ) . getDeclaredField ( "pipe" ) . get ( Record . Entity ) , this
							) ;
						}
						catch ( Throwable Throwable )
						{
							Throwable . printStackTrace ( ) ;
						}
					}
				}
				catch ( Throwable Throwable )
				{
				}
			}
		}
	}

	public BlockRecordSet Illusions = new BlockRecordSet ( ) ;

	public BlockRecord Lookup ( int X , int Y , int Z )
	{
		BlockRecord TargetRecord = new BlockRecord ( X , Y , Z ) ;

		BlockRecord FoundRecord = Ghosts . ceiling ( TargetRecord ) ;

		if ( FoundRecord != null )
		{
			if ( TargetRecord . compareTo ( FoundRecord ) == 0 )
			{
				return ( FoundRecord ) ;
			}
		}

		FoundRecord = Illusions . ceiling ( TargetRecord ) ;

		if ( FoundRecord != null )
		{
			if ( TargetRecord . compareTo ( FoundRecord ) == 0 )
			{
				return ( FoundRecord ) ;
			}
		}

		TargetRecord . Id = super . getBlockId ( X , Y , Z ) ;

		TargetRecord . Meta = super . getBlockMetadata ( X , Y , Z ) ;

		Illusions . add ( TargetRecord ) ;

		return ( TargetRecord ) ;
	}

	@Override
	public int getBlockId ( int X , int Y , int Z )
	{
		return ( Lookup ( X , Y , Z ) . Id ) ;
	}

	@Override
	public int getBlockMetadata ( int X , int Y , int Z )
	{
		return ( Lookup ( X , Y , Z ) . Meta ) ;
	}

	@Override
	public net . minecraft . tileentity . TileEntity getBlockTileEntity ( int X , int Y , int Z )
	{
		BlockRecord Record = Lookup ( X , Y , Z ) ;

		if ( Record . Entity == null )
		{
			Record . Entity = net . minecraft . block . Block . blocksList [ Record . Id ] . createTileEntity ( this , Record . Meta ) ;

			Record . Entity . xCoord = Record . X ;
			Record . Entity . yCoord = Record . Y ;
			Record . Entity . zCoord = Record . Z ;

			Record . Entity . worldObj = this ;

			Record . Entity . validate ( ) ;
		}

		return ( Record . Entity ) ;
	}

	@Override
	public boolean setBlock ( int X , int Y , int Z , int Id , int Meta , int Flags )
	{
		return ( false ) ;
	}

	@Override
	public boolean setBlockMetadataWithNotify ( int X , int Y , int Z , int Meta , int Flags )
	{
		return ( false ) ;
	}

	@Override
	public boolean setBlockToAir ( int X , int Y , int Z )
	{
		return ( false ) ;
	}

	@Override
	public boolean destroyBlock ( int X , int Y , int Z , boolean GenerateDrops )
	{
		return ( false ) ;
	}

	@Override
	public void markBlockForUpdate ( int X , int Y , int Z )
	{
	}

	@Override
	public void notifyBlockChange ( int X , int Y , int Z , int Id )
	{
	}

	@Override
	public void markBlocksDirtyVertical ( int X , int Z , int StartY , int EndY )
	{
	}

	@Override
	public void markBlockRangeForRenderUpdate ( int MinX , int MinY , int MinZ , int MaxX , int MaxY , int MaxZ )
	{
	}

	@Override
	public void notifyBlockOfNeighborChange ( int X , int Y , int Z , int Id )
	{
	}

	@Override
	public void setLightValue ( net . minecraft . world . EnumSkyBlock SkyBlockType , int X , int Y , int Z , int Value )
	{
	}

	@Override
	public void markBlockForRenderUpdate ( int X , int Y , int Z )
	{
	}

	@Override
	public boolean spawnEntityInWorld ( net . minecraft . entity . Entity Entity )
	{
		return ( false ) ;
	}

	@Override
	public void setBlockTileEntity ( int X , int Y , int Z , net . minecraft . tileentity . TileEntity TileEntity )
	{
	}

	@Override
	public void removeBlockTileEntity ( int X , int Y , int Z )
	{
	}

	@Override
	public net . minecraft . world . chunk . IChunkProvider createChunkProvider ( )
	{
		return ( null ) ;
	}

	@Override
	public net . minecraft . entity . Entity getEntityByID ( int Id )
	{
		return ( null ) ;
	}
}
