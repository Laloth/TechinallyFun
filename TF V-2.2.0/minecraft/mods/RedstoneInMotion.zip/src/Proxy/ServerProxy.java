package JAKJ . RedstoneInMotion ;

public class ServerProxy extends Proxy
{
}
