package JAKJ . RedstoneInMotion ;

import cpw . mods . fml . common . SidedProxy ;

public abstract class Proxy
{
	@SidedProxy ( clientSide = "JAKJ.RedstoneInMotion.ClientProxy" , serverSide = "JAKJ.RedstoneInMotion.ServerProxy" )
	public static Proxy Instance ;

	public void Initialize ( )
	{
	}
}
