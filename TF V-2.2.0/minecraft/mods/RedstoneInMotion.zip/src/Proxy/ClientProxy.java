package JAKJ . RedstoneInMotion ;

public class ClientProxy extends Proxy
{
	public void RegisterTileEntityRenderer ( TileEntityRenderer Renderer , Class < ? extends net . minecraft . tileentity . TileEntity > ... EntityClasses )
	{
		for ( Class < ? extends net . minecraft . tileentity . TileEntity > EntityClass : EntityClasses )
		{
			cpw . mods . fml . client . registry . ClientRegistry . bindTileEntitySpecialRenderer ( EntityClass , Renderer ) ;
		}
	}

	@Override
	public void Initialize ( )
	{
		RegisterTileEntityRenderer ( new MotiveSpectreRenderer ( ) , MotiveSpectreEntity . class ) ;

		RegisterTileEntityRenderer ( new TemplateCarriagePatternRenderer ( ) , TemplateCarriageEntity . class ) ;
	}
}
