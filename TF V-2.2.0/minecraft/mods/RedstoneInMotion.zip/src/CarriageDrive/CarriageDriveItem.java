package JAKJ . RedstoneInMotion ;

public class CarriageDriveItem extends net . minecraft . item . ItemBlock
{
	public CarriageDriveItem ( int Id )
	{
		super ( Id ) ;

		setHasSubtypes ( true ) ;
	}

	@Override
	public int getMetadata ( int Damage )
	{
		return ( Damage ) ;
	}

	@Override
	public String getItemDisplayName ( net . minecraft . item . ItemStack Item )
	{
		switch ( CarriageDrive . Types . values ( ) [ Item . itemDamage ] )
		{
			case Engine :

				return ( "Carriage Engine" ) ;

			case Motor :

				return ( "Carriage Drive" ) ;

			case Controller :

				return ( "Carriage Controller" ) ;
		}

		return ( null ) ;
	}

	@Override
	public void addInformation ( net . minecraft . item . ItemStack Item , net . minecraft . entity . player . EntityPlayer Player , java . util . List Lines , boolean Advanced )
	{
		switch ( CarriageDrive . Types . values ( ) [ Item . itemDamage ] )
		{
			case Engine :

				Lines . add ( "Moves with the carriage" ) ;

				break ;

			case Motor :

				Lines . add ( "Moves the carriage while staying put" ) ;

				break ;

			case Controller :

				Lines . add ( "Moves according to ComputerCraft control" ) ;

				break ;
		}
	}
}
