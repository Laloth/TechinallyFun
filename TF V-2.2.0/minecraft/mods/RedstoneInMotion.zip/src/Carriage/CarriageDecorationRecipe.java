package JAKJ . RedstoneInMotion ;

public class CarriageDecorationRecipe extends Recipe
{
	@Override
	public net . minecraft . item . ItemStack Process ( net . minecraft . inventory . InventoryCrafting Inventory )
	{
		net . minecraft . item . ItemStack Carriage = null ;

		net . minecraft . item . ItemStack Decoration = null ;

		int InventorySize = Inventory . getSizeInventory ( ) ;

		for ( int Index = 0 ; Index < InventorySize ; Index ++ )
		{
			net . minecraft . item .ItemStack Item = Inventory . getStackInSlot ( Index ) ;

			if ( Item == null )
			{
				continue ;
			}

			if ( Item . itemID == Blocks . Carriage . blockID )
			{
				if ( Carriage != null )
				{
					return ( null ) ;
				}

				Carriage = Item ;

				continue ;
			}

			if ( Decoration != null )
			{
				return ( null ) ;
			}

			Decoration = Item ;
		}

		if ( Carriage == null )
		{
			return ( null ) ;
		}

		int DecorationId = Carriage . itemDamage >> 8 ;

		if ( DecorationId == 0 )
		{
			if ( Decoration == null )
			{
				return ( null ) ;
			}

			if ( ! ( Decoration . getItem ( ) instanceof net . minecraft . item . ItemBlock ) )
			{
				return ( null ) ;
			}

			DecorationId = Decoration . itemID ;

			int DecorationMeta = Decoration . getItem ( ) . getMetadata ( Decoration . itemDamage ) ;

			return ( Stack . New ( Blocks . Carriage , ( DecorationId << 8 ) | ( DecorationMeta << 4 ) | Carriage . itemDamage ) ) ;
		}

		if ( Decoration != null )
		{
			return ( null ) ;
		}

		return ( Stack . New ( Blocks . Carriage , Carriage . itemDamage & 0xF ) ) ;
	}
}
