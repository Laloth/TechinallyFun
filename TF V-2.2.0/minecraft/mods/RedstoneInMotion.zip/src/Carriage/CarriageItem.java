package JAKJ . RedstoneInMotion ;

public class CarriageItem extends net . minecraft . item . ItemBlock
{
	public CarriageItem ( int Id )
	{
		super ( Id ) ;

		setHasSubtypes ( true ) ;
	}

	@Override
	public int getMetadata ( int Damage )
	{
		return ( Damage & 0xF ) ;
	}

	@Override
	public String getItemDisplayName ( net . minecraft . item . ItemStack Item )
	{
		/* TODO : remove */
		if ( Item . hasTagCompound ( ) )
		{
			net . minecraft . item . ItemStack Decoration = net . minecraft . item . ItemStack . loadItemStackFromNBT ( Item . getTagCompound ( ) . getCompoundTag ( "Decoration" ) ) ;

			Item . setTagCompound ( null ) ;

			int DecorationId = Decoration . itemID ;

			int DecorationMeta = Decoration . getItem ( ) . getMetadata ( Decoration . getItemDamage ( ) ) ;

			Item . itemDamage = ( DecorationId << 8 ) | ( DecorationMeta << 4 ) | Item . itemDamage ;
		}

		switch ( Carriage . Types . values ( ) [ Item . itemDamage & 0xF ] )
		{
			case Frame :

				return ( "Frame Carriage" ) ;

			case Platform :

				return ( "Platform Carriage" ) ;

			case Structure :

				return ( "Structure Carriage" ) ;

			case Support :

				return ( "Support Carriage" ) ;

			case Template :

				return ( "Template Carriage" ) ;
		}

		return ( null ) ;
	}

	@Override
	public void addInformation ( net . minecraft . item . ItemStack Item , net . minecraft . entity . player . EntityPlayer Player , java . util . List Lines , boolean Advanced )
	{
		switch ( Carriage . Types . values ( ) [ Item . itemDamage & 0xF ] )
		{
			case Frame :

				Lines . add ( "Carries blocks directly touching it" ) ;

				break ;

			case Platform :

				Lines . add ( "Carries entire body of blocks it's connected to" ) ;

				break ;

			case Structure :

				Lines . add ( "Carries entire cuboid of world" ) ;

				break ;

			case Support :

				Lines . add ( "Carries straight line of blocks" ) ;

				break ;

			case Template :

				Lines . add ( "Carries blocks in the exact pattern prepared" ) ;

				break ;
		}

		int DecorationId = Item . itemDamage >> 8 ;

		if ( DecorationId == 0 )
		{
			return ;
		}

		int DecorationMeta = ( Item . itemDamage >> 4 ) & 0xF ;

		net . minecraft . item . ItemStack Decoration = Stack . New ( DecorationId , DecorationMeta ) ;

		try
		{
			Lines . add ( "Decoration: " + Decoration . getItem ( ) . getItemDisplayName ( Decoration ) ) ;
		}
		catch ( Throwable Throwable )
		{
			Throwable . printStackTrace ( ) ;

			Lines . add ( "Decoration: <invalid>" ) ;
		}
	}
}
