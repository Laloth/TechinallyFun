package JAKJ . RedstoneInMotion ;

public class TemplateCarriagePatternRenderer extends TileEntityRenderer
{
	@Override
	public void Render ( net . minecraft . tileentity . TileEntity TileEntity , float PartialTick )
	{
		TemplateCarriageEntity Carriage = ( TemplateCarriageEntity ) TileEntity ;

		if ( Carriage . Pattern == null )
		{
			return ;
		}

		if ( Carriage . RenderPattern == false )
		{
			return ;
		}

		Render . ExecuteDisplayList ( Carriage . DisplayList ) ;
	}

	public static void FillDisplayList ( TemplateCarriageEntity Carriage )
	{
		net . minecraft . client . renderer . RenderHelper . disableStandardItemLighting ( ) ;

		BlockRenderer BlockRenderer = new BlockRenderer ( Carriage . worldObj ) ;

		RenderEngine . ResetBoundTexture ( ) ;

		RenderEngine . BindBlockTexture ( null ) ;

		BlockRenderer . setRenderBounds ( 0.0001 , 0.0001 , 0.0001 , 0.9999 , 0.9999 , 0.9999 ) ;

		BlockRenderer . Prepare ( Carriage . xCoord , Carriage . yCoord , Carriage . zCoord ) ;

		for ( BlockRecord Record : Carriage . Pattern )
		{
			BlockRenderer . Render ( Record . X , Record . Y , Record . Z , Spectre . PlaceholderIcon ) ;
		}

		net . minecraft . client . renderer . RenderHelper . enableStandardItemLighting ( ) ;
	}
}
