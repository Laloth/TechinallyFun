package JAKJ . RedstoneInMotion ;

public abstract class Recipes
{
	public static void Register ( )
	{
		RegisterSimpleItemRecipes ( ) ;

		RegisterToolItemRecipes ( ) ;

		RegisterCarriageRecipes ( ) ;

		RegisterCarriageDriveRecipes ( ) ;

		Registry . RegisterCustomRecipe ( new CarriageDecorationRecipe ( ) ) ;
	}

	public static void RegisterSimpleItemRecipes ( )
	{
/*
		Registry . RegisterShapedRecipe
		(
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageCrosspiece ) ,

			"S S" , " S " , "S S" ,

			'S' , new Stack ( net . minecraft . item . Item . stick )
		) ;

		Registry . RegisterShapedRecipe
		(
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel ) ,

			"SSS" , "SCS" , "SSS" ,

			'S' , new Stack ( net . minecraft . item . Item . stick ) ,
			'C' , new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageCrosspiece )
		) ;
*/

		Registry . RegisterShapelessRecipe
		(
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,

			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel )
		) ;

		Registry . RegisterCustomRecipe ( new net . minecraftforge . oredict . ShapedOreRecipe
		(
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageCrosspiece ) ,

			"S S" , " S " , "S S" ,

			'S' , "stickWood"
		) ) ;

		Registry . RegisterCustomRecipe ( new net . minecraftforge . oredict . ShapedOreRecipe
		(
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriagePanel ) ,

			"SSS" , "SCS" , "SSS" ,

			'S' , "stickWood" ,
			'C' , Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageCrosspiece )
		) ) ;
	}

	public static void RegisterToolItemRecipes ( )
	{
		Registry . RegisterShapedRecipe
		(
			new Stack ( Items . ToolItemSet , ToolItemSet . Types . Screwdriver ) ,

			" I " , " I " , "LSL" ,

			'I' , new Stack ( net . minecraft . item . Item . ingotIron ) ,
			'S' , new Stack ( net . minecraft . block . Block . cobblestone ) ,
			'L' , new Stack ( net . minecraft . item . Item . leather )
		) ;
	}

	public static void RegisterCarriageRecipe ( Carriage . Types CarriageType , String /* Vanilla . DyeTypes */ DyeType )
	{
/*
		Registry . RegisterShapelessRecipe
		(
			new Stack ( Blocks . Carriage , CarriageType , 8 ) ,

			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			new Stack ( net . minecraft . item . Item . dyePowder , DyeType )
		) ;
*/

		Registry . RegisterCustomRecipe ( new net . minecraftforge . oredict . ShapelessOreRecipe
		(
			Stack . New ( Blocks . Carriage , CarriageType , 8 ) ,

			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,
			Stack . New ( Items . SimpleItemSet , SimpleItemSet . Types . CarriageFramework ) ,

			DyeType
		) ) ;
	}

	public static void RegisterCarriageRecipes ( )
	{
		RegisterCarriageRecipe ( Carriage . Types . Frame , "dyeOrange" /* Vanilla . DyeTypes . Orange */ ) ;

		RegisterCarriageRecipe ( Carriage . Types . Platform , "dyeBlue" /* Vanilla . DyeTypes . Blue */ ) ;

		RegisterCarriageRecipe ( Carriage . Types . Structure , "dyeYellow" /* Vanilla . DyeTypes . Yellow */ ) ;

		RegisterCarriageRecipe ( Carriage . Types . Support , "dyeLime" /* Vanilla . DyeTypes . Lime */ ) ;

		RegisterCarriageRecipe ( Carriage . Types . Template , "dyePurple" /* Vanilla . DyeTypes . Purple */ ) ;
	}

	public static void RegisterCarriageDriveRecipes ( )
	{
		Registry . RegisterShapedRecipe
		(
			new Stack ( Blocks . CarriageDrive , CarriageDrive . Types . Motor ) ,

			"RFR" , "FIF" , "RFR" ,

			'R' , new Stack ( net . minecraft . block . Block . blockRedstone ) ,
			'F' , new Stack ( net . minecraft . block . Block . furnaceIdle ) ,
			'I' , new Stack ( net . minecraft . block . Block . blockIron )
		) ;

		Registry . RegisterShapedRecipe
		(
			new Stack ( Blocks . CarriageDrive , CarriageDrive . Types . Engine ) ,

			"TTT" , "TMT" , "TTT" ,

			'M' , new Stack ( Blocks . CarriageDrive , CarriageDrive . Types . Motor ) ,
			'T' , new Stack ( net . minecraft . block . Block . torchRedstoneActive )
		) ;

		if ( CarriageDrive . ControllerAvailable )
		{
			Registry . RegisterShapedRecipe
			(
				new Stack ( Blocks . CarriageDrive , CarriageDrive . Types . Controller ) ,

				"RRR" , "RMR" , "RRR" ,

				'R' , new Stack ( net . minecraft . item . Item . redstoneRepeater ) ,
				'M' , new Stack ( Blocks . CarriageDrive , CarriageDrive . Types . Motor )
			) ;
		}
	}
}
