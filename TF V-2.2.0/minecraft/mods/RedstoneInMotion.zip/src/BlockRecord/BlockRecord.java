package JAKJ . RedstoneInMotion ;

public class BlockRecord implements Comparable < BlockRecord >
{
	public int X ;
	public int Y ;
	public int Z ;

	public BlockRecord ( int X , int Y , int Z )
	{
		this . X = X ;
		this . Y = Y ;
		this . Z = Z ;
	}

	public BlockRecord ( BlockRecord Record )
	{
		X = Record . X ;
		Y = Record . Y ;
		Z = Record . Z ;
	}

	public void Shift ( Directions Direction )
	{
		X += Direction . DeltaX ;
		Y += Direction . DeltaY ;
		Z += Direction . DeltaZ ;
	}

	public BlockRecord NextInDirection ( Directions Direction )
	{
		return ( new BlockRecord ( X + Direction . DeltaX , Y + Direction . DeltaY , Z + Direction . DeltaZ ) ) ;
	}

	@Override
	public int compareTo ( BlockRecord Target )
	{
		int Result = X - Target . X ;

		if ( Result == 0 )
		{
			Result = Y - Target . Y ;

			if ( Result == 0 )
			{
				Result = Z - Target . Z ;
			}
		}

		return ( Result ) ;
	}

	public int Id ;

	public int Meta ;

	public net . minecraft . tileentity . TileEntity Entity ;

	public net . minecraft . nbt . NBTTagCompound EntityRecord ;

	public net . minecraft . nbt . NBTTagCompound EntityPacketRecord ;

	public BlockRecord ( NbtCompound TagCompound )
	{
	/*
		X = TagCompound . getInteger ( "X" ) ;
		Y = TagCompound . getInteger ( "Y" ) ;
		Z = TagCompound . getInteger ( "Z" ) ;

		Id = TagCompound . getInteger ( "Id" ) ;

		Meta = TagCompound . getInteger ( "Meta" ) ;

		EntityRecord = TagCompound . GetTagCompound ( "EntityRecord" ) ;

		EntityPacketRecord = TagCompound . GetTagCompound ( "RenderingRecord" ) ;
		*/
	}

	public NbtCompound GenerateTagCompound ( boolean ForClient )
	{
	/*
		NbtCompound TagCompound = new NbtCompound ( ) ;

		TagCompound . setInteger ( "X" , X ) ;
		TagCompound . setInteger ( "Y" , Y ) ;
		TagCompound . setInteger ( "Z" , Z ) ;

		TagCompound . setInteger ( "Id" , Id ) ;

		TagCompound . setInteger ( "Meta" , Meta ) ;

		if ( ForClient && ( RenderingRecord != null ) )
		{
			TagCompound . PutTagCompound ( "RenderingRecord" , RenderingRecord ) ;
		}
		else
		{
			TagCompound . PutTagCompound ( "EntityRecord" , EntityRecord ) ;
		}

		return ( TagCompound ) ;
		*/return ( null ) ;
	}

	public void Identify ( TileEntity Anchor )
	{
		Identify ( Anchor . worldObj ) ;
	}

	public void Identify ( net . minecraft . world . World World )
	{
		Id = World . getBlockId ( X , Y , Z ) ;

		Meta = World . getBlockMetadata ( X , Y , Z ) ;

		Entity = World . getBlockTileEntity ( X , Y , Z ) ;
	}

	public static BlockRecord Identified ( TileEntity Anchor , int X , int Y , int Z )
	{
		BlockRecord Record = new BlockRecord ( X , Y , Z ) ;

		Record . Identify ( Anchor ) ;

		return ( Record ) ;
	}
}
