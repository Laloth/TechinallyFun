package JAKJ . RedstoneInMotion ;

public class BlockRecordList extends java . util . ArrayList < BlockRecord >
{
	/* CHANGE TO CONSTRUCTOR */
	public static BlockRecordList GenerateFromTagList ( NbtList TagList )
	{
		BlockRecordList RecordList = new BlockRecordList ( ) ;

		for ( NbtCompound TagCompound : TagList )
		{
			RecordList . add ( new BlockRecord ( TagCompound ) ) ;
		}

		return ( RecordList ) ;
	}

	public NbtList GenerateTagList ( boolean ForClient )
	{
		NbtList TagList = new NbtList ( ) ;

		for ( BlockRecord Record : this )
		{
			TagList . appendTag ( Record . GenerateTagCompound ( ForClient ) ) ;
		}

		return ( TagList ) ;
	}
}
