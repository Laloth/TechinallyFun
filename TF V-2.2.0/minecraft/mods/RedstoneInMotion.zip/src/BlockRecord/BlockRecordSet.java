package JAKJ . RedstoneInMotion ;

public class BlockRecordSet extends java . util . TreeSet < BlockRecord >
{
	public BlockRecordSet ( )
	{
		super ( ) ;
	}

	public BlockRecordSet ( NbtList TagList )
	{
		super ( ) ;

		for ( NbtCompound TagCompound : TagList )
		{
			add ( new BlockRecord ( TagCompound ) ) ;
		}
	}

	public NbtList GenerateTagList ( boolean ForClient )
	{
		NbtList TagList = new NbtList ( ) ;

		for ( BlockRecord Record : this )
		{
			TagList . appendTag ( Record . GenerateTagCompound ( ForClient ) ) ;
		}

		return ( TagList ) ;
	}
}
