package JAKJ . RedstoneInMotion ;

public abstract class CarriagePackageBlacklist
{
	public static final java . util . HashSet < Integer > BlacklistedIds = new java . util . HashSet < Integer > ( ) ;

	public static final java . util . HashSet < Integer > BlacklistedIdAndMetaPairs = new java . util . HashSet < Integer > ( ) ;

	public static void Add ( int Id )
	{
		BlacklistedIds . add ( Id ) ;
	}

	public static void Add ( int Id , int Meta )
	{
		BlacklistedIdAndMetaPairs . add ( ( Id << 4 ) | Meta ) ;
	}

	public static boolean Lookup ( BlockRecord Block )
	{
		if ( BlacklistedIds . contains ( Block . Id ) )
		{
			return ( true ) ;
		}

		if ( BlacklistedIdAndMetaPairs . contains ( ( Block . Id << 4 ) | Block . Meta ) )
		{
			return ( true ) ;
		}

		return ( false ) ;
	}

	public static void Initialize ( )
	{
		Add ( net . minecraft . block . Block . bedrock . blockID ) ;

		Add ( Blocks . Spectre . blockID ) ;
	}
}
