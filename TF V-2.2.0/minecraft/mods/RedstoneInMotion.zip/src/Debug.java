package JAKJ . RedstoneInMotion ;

public abstract class Debug
{
	public static final String Label = "*-*-* REDSTONE IN MOTION *-*-*" ;

	public static void Emit ( Object ... Objects )
	{
		System . err . print ( Label + " -- " + cpw . mods . fml . common . FMLCommonHandler . instance ( ) . getEffectiveSide ( ) ) ;

		for ( Object Object : Objects )
		{
			System . err . print ( " -- " + Object ) ;
		}

		System . err . println ( ) ;
	}

	public static void EmitTrace ( )
	{
		new RuntimeException ( Label ) . printStackTrace ( ) ;
	}
}
