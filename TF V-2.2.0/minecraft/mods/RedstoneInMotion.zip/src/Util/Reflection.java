package JAKJ . RedstoneInMotion ;

public abstract class Reflection
{
	/*
	public static java . lang . reflect . Field GetField ( Class Class , String Name , boolean FailSilently )
	{
		try
		{
			java . lang . reflect . Field Field = Class . getDeclaredField ( Name ) ;

			Field . setAccessible ( true ) ;

			return ( Field ) ;
		}
		catch ( Throwable Throwable )
		{
			if ( FailSilently )
			{
				return ( null ) ;
			}

			throw ( new RuntimeException ( Throwable ) ) ;
		}
	}

	public static Object GetFieldValue ( Class Class , String Name , Object Object , boolean FailSilently )
	{
		try
		{
			return ( GetField ( Class , Name , FailSilently ) . get ( Object ) ) ;
		}
		catch ( Throwable Throwable )
		{
			if ( FailSilently )
			{
				return ( null ) ;
			}

			throw ( new RuntimeException ( Throwable ) ) ;
		}
	}

	public static void SetFieldValue ( Class Class , String Name , Object Object , Object Value , boolean FailSilently )
	{
		try
		{
			GetField ( Class , Name , FailSilently ) . set ( Object , Value ) ;
		}
		catch ( Throwable Throwable )
		{
			if ( FailSilently )
			{
				return ;
			}

			throw ( new RuntimeException ( Throwable ) ) ;
		}
	}

	public static void CopyFieldValue ( Class Class , String Name , Object Source , Object Sink , boolean FailSilently )
	{
		SetFieldValue ( Class , Name , Sink , GetFieldValue ( Class , Name , Source , FailSilently ) , FailSilently ) ;
	}

	public static java . lang . reflect . Method GetMethod ( Class Class , String Name , boolean FailSilently , Class ... Parameters )
	{
		try
		{
			java . lang . reflect . Method Method = Class . getDeclaredMethod ( Name , Parameters ) ;

			Method . setAccessible ( true ) ;

			return ( Method ) ;
		}
		catch ( Throwable Throwable )
		{
			if ( FailSilently )
			{
				return ( null ) ;
			}

			throw ( new RuntimeException ( Throwable ) ) ;
		}
	}

	public static Object InvokeMethod ( java . lang . reflect . Method Method , Object Object , boolean FailSilently , Object ... Arguments )
	{
		try
		{
			return ( Method . invoke ( Object , Arguments ) ) ;
		}
		catch ( Throwable Throwable )
		{
			if ( FailSilently )
			{
				return ( null ) ;
			}

			throw ( new RuntimeException ( Throwable ) ) ;
		}
	}
	*/
}
