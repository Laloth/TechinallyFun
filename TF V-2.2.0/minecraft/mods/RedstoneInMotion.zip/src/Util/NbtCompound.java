package JAKJ . RedstoneInMotion ;

public class NbtCompound extends net . minecraft . nbt . NBTTagCompound
{
	public NbtCompound ( )
	{
		super ( ) ;
	}

	public static final String NBTTagCompound_tagMap = "field_74784_a" ;

	public NbtCompound ( net . minecraft . nbt . NBTTagCompound TagCompound )
	{
		super ( TagCompound . getName ( ) ) ;

		// Reflection . CopyFieldValue ( net . minecraft . nbt . NBTTagCompound . class , NBTTagCompound_tagMap , TagCompound , this , false ) ;
		tagMap = TagCompound . tagMap ;
	}

	public void PutTagCompound ( String Key , NbtCompound TagCompound )
	{
		if ( TagCompound != null )
		{
			setCompoundTag ( Key , TagCompound ) ;
		}
	}

	public NbtCompound GetTagCompound ( String Key )
	{
		if ( hasKey ( Key ) )
		{
			return ( new NbtCompound ( getCompoundTag ( Key ) ) ) ;
		}

		return ( null ) ;
	}

	@Override
	public NbtList getTagList ( String Key )
	{
		return ( new NbtList ( super . getTagList ( Key ) ) ) ;
	}

	public void PutStack ( String Key , Stack Stack )
	{
		NbtCompound StackCompound = new NbtCompound ( ) ;

		Stack . Stack . writeToNBT ( StackCompound ) ;

		setCompoundTag ( Key , StackCompound ) ;
	}

	public Stack GetStack ( String Key )
	{
		if ( ! hasKey ( Key ) )
		{
			return ( null ) ;
		}

		return ( new Stack ( net . minecraft . item . ItemStack . loadItemStackFromNBT ( getCompoundTag ( Key ) ) ) ) ;
	}
}
