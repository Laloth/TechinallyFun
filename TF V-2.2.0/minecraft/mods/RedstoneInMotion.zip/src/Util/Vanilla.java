package JAKJ . RedstoneInMotion ;

public abstract class Vanilla
{
	public enum CoalTypes
	{
		Coal ,
		Charcoal ;
	}

	public enum DyeTypes
	{
		Black ,
		Red ,
		Green ,
		Brown ,
		Blue ,
		Purple ,
		Cyan ,
		LightGrey ,
		Grey ,
		Pink ,
		Lime ,
		Yellow ,
		LightBlue ,
		Magenta ,
		Orange ,
		White ;
	}
}
