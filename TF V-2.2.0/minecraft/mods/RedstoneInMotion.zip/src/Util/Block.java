package JAKJ . RedstoneInMotion ;

import java . util . List ;
import java . util . Random ;
import net . minecraft . creativetab . CreativeTabs ;
import net . minecraft . entity . EntityLiving ;
import net . minecraft . entity . player . EntityPlayer ;
import net . minecraft . item . ItemStack ;
import net . minecraft . util . Icon ;
import net . minecraft . world . IBlockAccess ;
import net . minecraft . world . World ;

public abstract class Block
{
	public static net . minecraft . block . Block Get ( int Id )
	{
		return ( net . minecraft . block . Block . blocksList [ Id ] ) ;
	}

	public static int Count ( )
	{
		return ( net . minecraft . block . Block . blocksList . length ) ;
	}
}
