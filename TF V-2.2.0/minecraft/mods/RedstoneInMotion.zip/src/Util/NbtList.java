package JAKJ . RedstoneInMotion ;

public class NbtList extends net . minecraft . nbt . NBTTagList implements Iterable < NbtCompound > , java . util . Iterator < NbtCompound >
{
	public NbtList ( )
	{
		super ( ) ;
	}

	public static final String NBTTagList_tagList = "field_74747_a" ;
	public static final String NBTTagList_tagType = "field_74746_b" ;

	public NbtList ( net . minecraft . nbt . NBTTagList TagList )
	{
		super ( TagList . getName ( ) ) ;

		/*
		Reflection . CopyFieldValue ( net . minecraft . nbt . NBTTagList . class , NBTTagList_tagList , TagList , this , false ) ;

		Reflection . CopyFieldValue ( net . minecraft . nbt . NBTTagList . class , NBTTagList_tagType , TagList , this , false ) ;
		*/

		tagList = TagList . tagList ;

		tagType = TagList . tagType ;
	}

	public int Index ;

	@Override
	public java . util . Iterator < NbtCompound > iterator ( )
	{
		Index = 0 ;

		return ( this ) ;
	}

	@Override
	public boolean hasNext ( )
	{
		return ( Index < tagCount ( ) ) ;
	}

	@Override
	public NbtCompound next ( )
	{
		NbtCompound TagCompound = new NbtCompound ( ( net . minecraft . nbt . NBTTagCompound ) tagAt ( Index ) ) ;

		Index ++ ;

		return ( TagCompound ) ;
	}

	@Override
	public void remove ( )
	{
	}
}
