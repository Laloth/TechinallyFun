package JAKJ . RedstoneInMotion ;

public abstract class TileEntity extends net . minecraft . tileentity . TileEntity
{
	public void ReadFromNbt ( NbtCompound TagCompound , boolean FromServer )
	{
	}

	@Override
	public void readFromNBT ( net . minecraft . nbt . NBTTagCompound TagCompound )
	{
		super . readFromNBT ( TagCompound ) ;

		ReadFromNbt ( new NbtCompound ( TagCompound ) , false ) ;
	}

	@Override
	public void onDataPacket ( net . minecraft . network . INetworkManager NetworkManager , net . minecraft . network . packet . Packet132TileEntityData Packet )
	{
		super . readFromNBT ( Packet . customParam1 ) ;

		ReadFromNbt ( new NbtCompound ( Packet . customParam1 ) , true ) ;

		worldObj . markBlockForRenderUpdate ( xCoord , yCoord , zCoord ) ;
	}

	public void WriteToNbt ( NbtCompound TagCompound , boolean ToClient )
	{
	}

	@Override
	public void writeToNBT ( net . minecraft . nbt . NBTTagCompound TagCompound )
	{
		super . writeToNBT ( TagCompound ) ;

		WriteToNbt ( new NbtCompound ( TagCompound ) , false ) ;
	}

	@Override
	public net . minecraft . network . packet . Packet132TileEntityData getDescriptionPacket ( )
	{
		net . minecraft . network . packet . Packet132TileEntityData Packet = new net . minecraft . network . packet . Packet132TileEntityData ( xCoord , yCoord , zCoord , 0 , new NbtCompound ( ) ) ;

		super . writeToNBT ( Packet . customParam1 ) ;

		WriteToNbt ( ( NbtCompound ) Packet . customParam1 , true ) ;

		return ( Packet ) ;
	}

	public void Propagate ( )
	{
		worldObj . notifyBlockChange ( xCoord , yCoord , zCoord , worldObj . getBlockId ( xCoord , yCoord , zCoord ) ) ;

		worldObj . markBlockForUpdate ( xCoord , yCoord , zCoord ) ;

		worldObj . getChunkFromChunkCoords ( xCoord >> 4 , zCoord >> 4 ) . setChunkModified ( ) ;
	}

	public void Initialize ( Stack Stack , double PlacementYaw )
	{
	}

	public void Finalize ( )
	{
	}

	@Override
	public void invalidate ( )
	{
		Finalize ( ) ;

		super . invalidate ( ) ;
	}
}
