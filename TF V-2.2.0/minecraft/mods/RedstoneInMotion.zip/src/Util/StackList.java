package JAKJ . RedstoneInMotion ;

public class StackList extends java . util . ArrayList < Stack >
{
}
