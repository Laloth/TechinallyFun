package JAKJ . RedstoneInMotion ;

import java . util . List ;
import net . minecraft . creativetab . CreativeTabs ;
import net . minecraft . entity . player . EntityPlayer ;
import net . minecraft . item . ItemStack ;
import net . minecraft . util . Icon ;
import net . minecraft . world . World ;

public abstract class Item extends net . minecraft . item . Item
{
	public String DefaultHandle ( )
	{
		return ( getClass ( ) . getSimpleName ( ) ) ;
	}

	public Item ( int Id )
	{
		super ( Id ) ;

		setUnlocalizedName ( Core . Handle + "_" + DefaultHandle ( ) ) ;

		setHasSubtypes ( true ) ;

		setCreativeTab ( CreativeTab . Instance ) ;

		Registry . RegisterItem ( this ) ;
	}

	public int GetId ( )
	{
		return ( itemID ) ;
	}

	public abstract String GetName ( Stack Stack ) ;

	@Override
	public String getItemDisplayName ( ItemStack Stack )
	{
		return ( GetName ( new Stack ( Stack ) ) ) ;
	}

	public List ShowcaseStackList ;

	public void RegisterShowcaseStack ( Stack Stack )
	{
		ShowcaseStackList . add ( Stack . Stack ) ;
	}

	public void RegisterShowcaseStacks ( )
	{
	}

	@Override
	public void getSubItems ( int Id , CreativeTabs Tab , List List )
	{
		ShowcaseStackList = List ;

		RegisterShowcaseStacks ( ) ;

		ShowcaseStackList = null ;
	}

	public void RegisterIcons ( IconRegister Register )
	{
	}

	@Override
	public void registerIcons ( net . minecraft . client . renderer . texture . IconRegister Register )
	{
		RegisterIcons ( new IconRegister ( Register ) ) ;
	}

	public abstract IconHolder GetIcon ( int Damage ) ;

	@Override
	public Icon getIconFromDamage ( int Damage )
	{
		return ( GetIcon ( Damage ) . Icon ) ;
	}

	public List AdditionalTooltipLines ;

	public void PopulateTooltip ( String Line )
	{
		AdditionalTooltipLines . add ( Line ) ;
	}

	public void PopulateTooltip ( Stack Stack )
	{
	}

	@Override
	public void addInformation ( ItemStack Stack , EntityPlayer Player , List Lines , boolean Advanced )
	{
		AdditionalTooltipLines = Lines ;

		PopulateTooltip ( new Stack ( Stack ) ) ;

		AdditionalTooltipLines = null ;
	}

	public boolean HasEnchantmentEffect ( Stack Stack )
	{
		return ( false ) ;
	}

	@Override
	public boolean hasEffect ( ItemStack Stack )
	{
		return ( HasEnchantmentEffect ( new Stack ( Stack ) ) ) ;
	}

	@Override
	public boolean shouldPassSneakingClickToBlock ( net . minecraft . world . World World , int X , int Y , int Z )
	{
		return ( true ) ;
	}
}
