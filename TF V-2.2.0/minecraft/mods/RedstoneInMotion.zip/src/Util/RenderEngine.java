package JAKJ . RedstoneInMotion ;

public abstract class RenderEngine
{
	public static net . minecraft . client . renderer . RenderEngine RenderEngine ( )
	{
		return ( net . minecraft . client . Minecraft . getMinecraft ( ) . renderEngine ) ;
	}

	public static void ResetBoundTexture ( )
	{
		RenderEngine ( ) . resetBoundTexture ( ) ;
	}

	public static void BindDefaultBlockTexture ( )
	{
		RenderEngine ( ) . textureMapBlocks . getTexture ( ) . bindTexture ( 0 ) ;
	}

	public static void BindTexture ( String Path )
	{
		RenderEngine ( ) . bindTexture ( Path ) ;
	}

	public static void BindBlockTexture ( String Path )
	{
		if ( Path == null )
		{
			BindDefaultBlockTexture ( ) ;
		}
		else
		{
			BindTexture ( Path ) ;
		}
	}

	public static net . minecraft . util . Icon GetBlockIcon ( int Id , int Side , int Meta )
	{
		net . minecraft . util . Icon Icon = null ;

		try
		{
			Icon = Block . Get ( Id ) . getIcon ( Side , Meta ) ;
		}
		catch ( Throwable Throwable )
		{
			Throwable . printStackTrace ( ) ;
		}

		if ( Icon == null )
		{
			return ( RenderEngine ( ) . textureMapBlocks . getMissingIcon ( ) ) ;
		}

		return ( Icon ) ;
	}
}
