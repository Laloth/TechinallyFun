package JAKJ . RedstoneInMotion ;

public class IconRegister
{
	public final net . minecraft . client . renderer . texture . IconRegister Register ;

	public IconRegister ( net . minecraft . client . renderer . texture . IconRegister Register )
	{
		this . Register = Register ;
	}

	public void Register ( IconHolder Icon )
	{
//		Icon . Icon = Register . registerIcon ( Icon . GetFullHandle ( ) ) ;

		Icon . Icon = Registry . RegisterIcon ( Register , Icon . Handle ) ;
	}
}
