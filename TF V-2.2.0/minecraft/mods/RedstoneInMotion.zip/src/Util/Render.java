package JAKJ . RedstoneInMotion ;

public abstract class Render
{
	public static void PushMatrix ( )
	{
		org . lwjgl . opengl . GL11 . glPushMatrix ( ) ;
	}

	public static void PopMatrix ( )
	{
		org . lwjgl . opengl . GL11 . glPopMatrix ( ) ;
	}

	public static void Translate ( double X , double Y , double Z )
	{
		org . lwjgl . opengl . GL11 . glTranslated ( X , Y , Z ) ;
	}

	public static void Rotate ( double Angle , double I , double J , double K )
	{
		org . lwjgl . opengl . GL11 . glRotatef ( ( float ) Angle , ( float ) I , ( float ) J , ( float ) K ) ;
	}

	public static void Scale ( double X , double Y , double Z )
	{
		org . lwjgl . opengl . GL11 . glScaled ( X , Y , Z ) ;
	}

	public static int InitializeDisplayList ( )
	{
		int DisplayList = org . lwjgl . opengl . GL11 . glGenLists ( 1 ) ;

		org . lwjgl . opengl . GL11 . glNewList ( DisplayList , org . lwjgl . opengl . GL11 . GL_COMPILE ) ;

		return ( DisplayList ) ;
	}

	public static void FinalizeDisplayList ( )
	{
		org . lwjgl . opengl . GL11 . glEndList ( ) ;
	}

	public static void ExecuteDisplayList ( int DisplayList )
	{
		org . lwjgl . opengl . GL11 . glCallList ( DisplayList ) ;
	}

	public static void ReleaseDisplayList ( int DisplayList )
	{
		if ( DisplayList == 0 )
		{
			return ;
		}

		org . lwjgl . opengl . GL11 . glDeleteLists ( DisplayList , 1 ) ;
	}
}
