package JAKJ . RedstoneInMotion ;

public class Stack
{
	public static net . minecraft . item . ItemStack New ( int Id , int Damage , int Quantity )
	{
		return ( new net . minecraft . item . ItemStack ( Id , Quantity , Damage ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( int Id , int Damage )
	{
		return ( New ( Id , Damage , 1 ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( int Id )
	{
		return ( New ( Id , 0 ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . item . Item Item , int Damage , int Quantity )
	{
		return ( New ( Item . itemID , Damage , Quantity ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . item . Item Item , Enum Type , int Quantity )
	{
		return ( New ( Item , Type . ordinal ( ) , Quantity ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . item . Item Item , int Damage )
	{
		return ( New ( Item , Damage , 1 ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . item . Item Item , Enum Type )
	{
		return ( New ( Item , Type , 1 ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . item . Item Item )
	{
		return ( New ( Item , 0 ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . block . Block Block , int Damage , int Quantity )
	{
		return ( New ( Block . blockID , Damage , Quantity ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . block . Block Block , Enum Type , int Quantity )
	{
		return ( New ( Block , Type . ordinal ( ) , Quantity ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . block . Block Block , int Damage )
	{
		return ( New ( Block , Damage , 1 ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . block . Block Block , Enum Type )
	{
		return ( New ( Block , Type , 1 ) ) ;
	}

	public static net . minecraft . item . ItemStack New ( net . minecraft . block . Block Block )
	{
		return ( New ( Block , 0 ) ) ;
	}

	public final net . minecraft . item . ItemStack Stack ;

	public Stack ( net . minecraft . item . ItemStack Stack )
	{
		this . Stack = Stack ;
	}

	public Stack ( int Id , int Damage , int Quantity )
	{
		this ( new net . minecraft . item . ItemStack ( Id , Quantity , Damage ) ) ;
	}

	public Stack ( net . minecraft . item . Item Item , int Damage , int Quantity )
	{
		this ( Item . itemID , Damage , Quantity ) ;
	}

	public Stack ( net . minecraft . block . Block Block , int Damage , int Quantity )
	{
		this ( Block . blockID , Damage , Quantity ) ;
	}

	public Stack ( net . minecraft . item . Item Item , Enum Type , int Quantity )
	{
		this ( Item , Type . ordinal ( ) , Quantity ) ;
	}

	public Stack ( net . minecraft . block . Block Block , Enum Type , int Quantity )
	{
		this ( Block . blockID , Type . ordinal ( ) , Quantity ) ;
	}

	public Stack ( net . minecraft . item . Item Item , int Damage )
	{
		this ( Item , Damage , 1 ) ;
	}

	public Stack ( net . minecraft . block . Block Block , int Damage )
	{
		this ( Block , Damage , 1 ) ;
	}

	public Stack ( net . minecraft . item . Item Item , Enum Type )
	{
		this ( Item , Type , 1 ) ;
	}

	public Stack ( net . minecraft . block . Block Block , Enum Type )
	{
		this ( Block , Type , 1 ) ;
	}

	public Stack ( net . minecraft . item . Item Item )
	{
		this ( Item , 0 ) ;
	}

	public Stack ( net . minecraft . block . Block Block )
	{
		this ( Block , 0 ) ;
	}

	public boolean HasTag ( )
	{
		return ( Stack . getTagCompound ( ) != null ) ;
	}

	public void AddTag ( )
	{
		Stack . setTagCompound ( new NbtCompound ( ) ) ;
	}

	public void RemoveTag ( )
	{
		Stack . setTagCompound ( null ) ;
	}

	public void SetId ( int Id )
	{
		Stack . itemID = Id ;
	}

	public int GetId ( )
	{
		return ( Stack . itemID ) ;
	}

	public void SetDamage ( int Damage )
	{
		Stack . setItemDamage ( Damage ) ;
	}

	public int GetDamage ( )
	{
		return ( Stack . getItemDamage ( ) ) ;
	}

	public void SetInteger ( String Key , int Value )
	{
		Stack . getTagCompound ( ) . setInteger ( Key , Value ) ;
	}

	public int GetInteger ( String Key )
	{
		return ( Stack . getTagCompound ( ) . getInteger ( Key ) ) ;
	}

	public void SetDouble ( String Key , Double Value )
	{
		Stack . getTagCompound ( ) . setDouble ( Key , Value ) ;
	}

	public double GetDouble ( String Key )
	{
		return ( Stack . getTagCompound ( ) . getDouble ( Key ) ) ;
	}

	public void SetBoolean ( String Key , boolean Value )
	{
		Stack . getTagCompound ( ) . setBoolean ( Key , Value ) ;
	}

	public boolean GetBoolean ( String Key )
	{
		return ( Stack . getTagCompound ( ) . getBoolean ( Key ) ) ;
	}

	public void SetStack ( String Key , Stack Stack )
	{
		new NbtCompound ( this . Stack . getTagCompound ( ) ) . PutStack ( Key , Stack ) ;
	}

	public Stack GetStack ( String Key )
	{
		return ( new NbtCompound ( Stack . getTagCompound ( ) ) . GetStack ( Key ) ) ;
	}
}
