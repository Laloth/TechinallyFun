package JAKJ . RedstoneInMotion ;

public class IconHolder
{
	public final String Handle ;

	public IconHolder ( String Handle )
	{
		this . Handle = Handle ;
	}

	public String GetFullHandle ( )
	{
		return ( Core . Handle + ":" + Handle ) ;
	}

	public net . minecraft . util . Icon Icon ;

	public static final IconHolder IconWrapper = new IconHolder ( null ) ;

	public static IconHolder Wrap ( net . minecraft . util . Icon Icon )
	{
		IconWrapper . Icon = Icon ;

		return ( IconWrapper ) ;
	}
}
