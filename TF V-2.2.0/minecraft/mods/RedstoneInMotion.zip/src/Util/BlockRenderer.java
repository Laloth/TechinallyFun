package JAKJ . RedstoneInMotion ;

public class BlockRenderer extends net . minecraft . client . renderer . RenderBlocks
{
	public BlockRenderer ( net . minecraft . world . IBlockAccess World )
	{
		super ( World ) ;
	}

	public int Brightness ;

	public void Prepare ( int X , int Y , int Z )
	{
		Brightness = net . minecraft . block . Block . blocksList [ blockAccess . getBlockId ( X , Y , Z ) ] . getMixedBrightnessForBlock ( blockAccess , X , Y , Z ) ;
	}

	public void SetColor ( double FactorR , double FactorG , double FactorB )
	{
		net . minecraft . client . renderer . Tessellator . instance . setBrightness ( Brightness ) ;

		net . minecraft . client . renderer . Tessellator . instance . setColorOpaque_F ( ( float ) FactorR , ( float ) FactorG , ( float ) FactorB ) ;
	}

	public void Render ( int X , int Y , int Z , net . minecraft . util . Icon Icon )
	{
		Render ( X , Y , Z , Icon , Icon , Icon , Icon , Icon , Icon ) ;
	}

	public void Render ( int X , int Y , int Z , net . minecraft . util . Icon ... Icons )
	{
		net . minecraft . client . renderer . Tessellator . instance . startDrawingQuads ( ) ;

		SetColor ( 0.5 , 0.5 , 0.5 ) ;
		renderFaceYNeg ( null , X , Y , Z , Icons [ 0 ] ) ;

		SetColor ( 1 , 1 , 1 ) ;
		renderFaceYPos ( null , X , Y , Z , Icons [ 1 ] ) ;

		SetColor ( 0.8 , 0.8 , 0.8 ) ;
		renderFaceZNeg ( null , X , Y , Z , Icons [ 2 ] ) ;

		SetColor ( 0.8 , 0.8 , 0.8 ) ;
		renderFaceZPos ( null , X , Y , Z , Icons [ 3 ] ) ;

		SetColor ( 0.6 , 0.6 , 0.6 ) ;
		renderFaceXNeg ( null , X , Y , Z , Icons [ 4 ] ) ;

		SetColor ( 0.6 , 0.6 , 0.6 ) ;
		renderFaceXPos ( null , X , Y , Z , Icons [ 5 ] ) ;

		net . minecraft . client . renderer . Tessellator . instance . draw ( ) ;
	}
}
