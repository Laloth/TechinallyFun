package JAKJ . RedstoneInMotion ;

public abstract class ModInteraction
{
	public static Class OmniwrenchClass ;

	public static void Establish ( )
	{
		try
		{
			OmniwrenchClass = Class . forName ( "omnitools.item.ItemWrench" ) ;
		}
		catch ( Throwable Throwable )
		{
		}
	}
}
