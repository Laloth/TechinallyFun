package JAKJ . RedstoneInMotion ;

@cpw . mods . fml . common . Mod ( modid = Core . Handle , name = Core . Name , version = Core . Version )
@cpw . mods . fml . common . network . NetworkMod ( clientSideRequired = true , serverSideRequired = false , channels = { "JAKJ_RIM" } , packetHandler = PacketHandler . class )
public class Core
{
	public static final String Handle = "JAKJ_RedstoneInMotion" ;

	public static final String Name = "Redstone In Motion" ;

	public static final String Version = "1.2.0.0" ;

	@cpw . mods . fml . common . Mod . PreInit
	public void PreInit ( cpw . mods . fml . common . event . FMLPreInitializationEvent Event )
	{
		( new Configuration ( Event . getSuggestedConfigurationFile ( ) ) ) . Process ( ) ;
	}

	@cpw . mods . fml . common . Mod . Init
	public void Init ( cpw . mods . fml . common . event . FMLInitializationEvent Event )
	{
		ModInteraction . Establish ( ) ;

		CreativeTab . Initialize ( ) ;

		Blocks . Initialize ( ) ;

		Items . Initialize ( ) ;
	}

	@cpw . mods . fml . common . Mod . PostInit
	public void PostInit ( cpw . mods . fml . common . event . FMLPostInitializationEvent Event )
	{
		Proxy . Instance . Initialize ( ) ;

		Recipes . Register ( ) ;

		CarriagePackageBlacklist . Initialize ( ) ;
	}
}
